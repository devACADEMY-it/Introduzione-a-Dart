import 'dart:async';

void main() {
  var future =
      Future.delayed(Duration(seconds: 5), () => throw 'Error!').then((value) {
    print("Value: $value");
  }).catchError((error) {
    print("Error: $error");
  });

  print("Main");
}
