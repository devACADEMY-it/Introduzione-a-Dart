import 'dart:async';

void makeRequest() async {
  var value = await getValue();
  print("Value: $value");
}

Future<int> getValue() {
  return Future.delayed(Duration(seconds: 5), () => 20);
}

void main() {
  makeRequest();
  print("Main");
}
