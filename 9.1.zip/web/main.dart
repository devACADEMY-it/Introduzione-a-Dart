import 'dart:html';

void main() {
  querySelector('#output')?.text = 'Prima web app con Dart';
}
