// Base class
class Animale {}

// Sottoclassi principali
class Mammifero extends Animale {}

class Pesce extends Animale {}

class Uccello extends Animale {}

// Caratteristiche aggiuntive
mixin Cammina {
  void cammina() {
    print("Io cammino");
  }
}

mixin Vola {
  void vola() {
    print("Io volo");
  }
}

mixin Nuota {
  void nuota() {
    print("Io nuoto");
  }
}

// Animali
class Gatto extends Mammifero with Cammina {}

class Delfino extends Mammifero with Cammina {}

class Anatra extends Uccello with Vola {}

class Colomba extends Uccello with Vola {}

class Squalo extends Pesce with Nuota {}

class Salmone extends Pesce with Nuota {}

void main() {
  Gatto g = new Gatto();
  g.cammina();

  Anatra a = new Anatra();
  a.vola();

  Squalo s = new Squalo();
  s.nuota();
}
