bool isEven(int num) {
  return num % 2 == 0;
}

void main() {
  int x = 3;

  if (x == 0) {
    print("$x è uguale a 0");
  } else if (isEven(x)) {
    print("$x è pari");
  } else {
    print("$x è dispari");
  }

  x = 8;
}
