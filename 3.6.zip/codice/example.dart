import 'dart:math';

void main() {
  var numbers = [];
  var random = new Random();

  /*
  int newNumber = -1;
  newNumber = random.nextInt(20);
  print("è stato generato il numero $newNumber");
  while (!numbers.contains(newNumber)) {
    numbers.add(newNumber);

    newNumber = random.nextInt(20);
    print("è stato generato il numero $newNumber");
  }
  print("$numbers");
  */

  /*
  for (var counter = 0; counter < 10; counter++) {
    numbers.add(random.nextInt(10));
  }
  print(numbers);
  */

  var counter = 11;
/*
  while (counter < 10) {
    numbers.add(random.nextInt(10));

    counter++;
  }
  print(numbers);
*/

  do {
    numbers.add(random.nextInt(10));

    counter++;
  } while (counter < 10);
  print(numbers);
}
