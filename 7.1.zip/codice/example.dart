void main() {
  /*
  List list = [1, 4, 5, 11, 2, 7, 128, 11];
  int length = list.length; // 7
  int first = list.first; // 1
  int last = list.last; // 128
  bool isEmpty = list.isEmpty; // false
  bool isEmpty = list.isNotEmpty; // true
  var reversed = list.reversed;

  list.add(50); // [1, 4, 5, 11, 2, 7, 128, 50]
  list.remove(1); // [4, 5, 11, 2, 7, 128]
  list.removeAt(2); // [[1, 4, 11, 2, 7, 128]]
  list.contains(3); // false
  list.elementAt(4); // 2
  list.indexOf(11); // 3
  list.insert(1, 6); // [1, 6, 4, 5, 11, 2, 7, 128]

  list[0] = 14;
  var list2 = [98, 97, 99];
  var list3;

  var nuovaLista = [
    ...list,
    ...list2
  ]; // [1, 4, 5, 11, 2, 7, 128, 11, 98, 97, 99];
  var l = [0, ...?list3]; // [0];
  */

  var isPromoActive = true;
  // Outlet è da mostrare solo se isPromoActive è true
  var menus = ['Home', 'Prodotti', 'Blog', if (isPromoActive) 'Outlet'];
  print(menus);
}
