void main() {
  var tavolaPeriodica = {
    8: {'symbol': 'O', 'name': 'Ossigeno'},
    16: {'symbol': 'S', 'name': 'Zolfo'},
    34: {'symbol': 'Se', 'name': 'Selenio'},
    52: {'symbol': 'Te', 'name': 'Tellurio'}
  };

  var entries = tavolaPeriodica.entries;
  print(entries);
}
