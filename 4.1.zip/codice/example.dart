// Scrivere una funzione che prende in input un intero positivo n
// e ritorna la somma dei cubi da 1 ad n
int sumCubes(int n) {
  int sum = 0;
  if (n < 1) {
    return -1;
  } else {
    /*
    for (var i = 1; i <= n; i++) {
      int cube = i * i * i;
      sum += cube;
    }
    */
    var i = 1;
    while (i <= n) {
      int cube = i * i * i;
      sum += cube;

      i++;
    }
  }
  return sum;
}

void main() {
  print(sumCubes(2)); // 1^3 + 2^3 = 1 + 8 = 9
  print(sumCubes(3)); // 1^3 + 2^3 + 3^3 = 1 + 8 + 27 = 36
  print(sumCubes(1)); // 1^3 = 1
  print(sumCubes(9)); // -1
}
