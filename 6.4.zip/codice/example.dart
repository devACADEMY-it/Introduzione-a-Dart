import 'dart:math';

class Point {
  double x = 0;
  double y = 0;
  static double PI = 3.14;

  Point(this.x, this.y) {}

  static double distance(Point a, Point b) {
    var dx = a.x - b.x;
    var dy = a.y - b.y;
    var distance = sqrt((dx * dx) + (dy * dy));
    return distance;
  }

  double distanceFrom(Point b) {
    var dx = this.x - b.x;
    var dy = this.y - b.y;
    var distance = sqrt((dx * dx) + (dy * dy));
    return distance;
  }
}

void main() {
  var p1 = new Point(2, 2);
  var p2 = new Point(4, 4);

  print(p1.distanceFrom(p2));
  print(Point.distance(p1, p2));
  print(20 * Point.PI);
}
