void main() {
  var a = 10;
  var b = 5.4;
  var c = true;
  var d = "Adriano";

  print(a.runtimeType);
  print(b.runtimeType);
  print(c.runtimeType);
  print(d.runtimeType);
}
