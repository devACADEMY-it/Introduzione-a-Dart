String saluta({required String from, String? msg = "ciao"}) {
  return '$from saluta dicendo $msg';
}

void main() {
  var result = saluta(from: "Adriano");
  print(result);
}
