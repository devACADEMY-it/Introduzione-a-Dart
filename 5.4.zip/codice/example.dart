class Person {
  String name = '';
  String surname = '';
  DateTime dateOfBirth;

  int get age => DateTime.now().difference(dateOfBirth).inDays ~/ 365;

  Person(this.name, this.surname, this.dateOfBirth);

  void describe() {
    print("$name $surname, nato il $dateOfBirth ($age anni)");
  }
}

class Student extends Person {
  String badgeNumber = '';
  String department = '';

  Student(name, surname, dateOfBirth, this.badgeNumber, this.department)
      : super(name, surname, dateOfBirth);
}

void main() {
  // Person p = new Person("Adriano", "Grimaldi", DateTime(1991, 10, 9));
  // p.describe();
  Student s = new Student("Adriano", "Grimaldi", DateTime(1991, 10, 9),
      "0132518525", "Informatica");
  s.describe();
}
