var global = "Global";

void main() {
  var insideMain = "insideMain";

  void A() {
    var insideA = "insideA";

    void B() {
      var insideB = "insideB";

      print(insideB);
      print(insideA);
      print(insideMain);
      print(global);
    }

    B();
  }

  A();
}
