// nome: Voyager 1
// lancio: 5 settembre 1977
// potenza: 420 W
// peso: 825.5 Kg

class SondaSpaziale {
  String nome = '';
  DateTime? dataLancio;
  double potenza = 0;
  double peso = 0;

  SondaSpaziale(this.nome, this.dataLancio, this.potenza, this.peso) {}

  SondaSpaziale.unlaunched(nome) {
    this.nome = nome;
  }

  void describe() {
    print("Sonda spaziale $nome");
    var dataLancio = this.dataLancio;
    if (dataLancio != null) {
      int anniDalLancio = DateTime.now().difference(dataLancio).inDays ~/ 365;
      print("Lanciata $dataLancio ($anniDalLancio anni fa)");
    } else {
      print("Non lanciata");
    }
  }
}

void main() {
  /*
  Map sonda = {
    nome: "Voyager 1",
    dataLancio: DateTime(1977, 9, 5),
    potenza: 420,
    peso: 825.5
  };
  */

  var voyager1 =
      new SondaSpaziale("Voyager 1", DateTime(1977, 9, 5), 420.0, 825.5);
  var voyager2 =
      new SondaSpaziale("Voyager 2", DateTime(1977, 8, 20), 420.0, 825.5);
  var voyager3 = SondaSpaziale.unlaunched("Voyager 3");

  voyager1.describe();
  voyager2.describe();
  voyager3.describe();
}
