// In una piccola città la popolazione all'inizio dell'anno è di 1000 abitanti.
// La popolazione cresce del 2% ogni anno.
// Inoltre, ogni anno arrivano 50 nuovi abitanti da fuori.
// Quanti anni impiegherà la città per arrivare a più di 1200 abitanti?

/*
1000
y1:1000 => 1000 * 0.02 + 50 = 1020 + 50 = 1070
y2:1070 => 1070 * 0.02 + 50 = 1091 + 50 = 1141
y3:1141 => 1141 * 0.02 + 50 = 1141 + 22 + 50 = 1213
// 3 
*/

int total_years(population, perc, incoming, maxPopulation) {
  int years = 0;
  while (population < maxPopulation) {
    population += (population * (perc / 100)) + incoming;
    years++;
  }
  return years;
}

void main() {
  print(total_years(1000, 2, 50, 1200)); // 3
  print(total_years(1500000, 2.5, 10000, 2000000)); // 10
}
