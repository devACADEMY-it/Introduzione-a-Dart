void main() {
  var a = 10;
  print("Hello, DART! $a");
}
