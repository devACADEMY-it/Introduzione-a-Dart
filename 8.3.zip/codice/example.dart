import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

class Album {
  final int userId;
  final int id;
  final String title;

  Album({this.userId, this.id, this.title});

  factory Album.fromJSON(Map<String, dynamic> json) {
    return Album(id: json['id'], userId: json['userId'], title: json['title']);
  }
}

Future<Album> fetchAlbum() async {
  var response = await http
      .get(Uri.parse('https://jsonplaceholder.typicode.com/albums/4'));

  if (response.statusCode == 200) {
    return Album.fromJSON(jsonDecode(response.body));
  } else {
    throw Exception('Failed to load album');
  }
}

void main() async {
  Album album = await fetchAlbum();
  print(album.title);
}
