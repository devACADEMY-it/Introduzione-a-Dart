bool isSuperhero(String hero) {
  return true;
}

void main() {
  // var checkIfIsSuperhero = isSuperhero;
  // print(checkIfIsSuperhero.runtimeType);

  print(isSuperhero('Batman'));
}
