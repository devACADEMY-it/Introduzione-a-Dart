late String name;

void main() {
  const double PI = 3.14;
  final int MULTIPLIER;

  MULTIPLIER = 4;

  name = "Adriano";
  print(name);

  print(PI);
  print(MULTIPLIER);
}
