import 'dart:html';
import 'dart:async';
import 'dart:convert';

final UListElement wordList = querySelector("#wordList") as UListElement;

void main() {
  querySelector('#getWords')!.onClick.listen(makeRequest);
}

Future<void> makeRequest(Event _) async {
  const path = 'https://dart.dev/f/portmanteaux.json';
  try {
    final jsonString = await HttpRequest.getString(path);
    readJSON(jsonString);
  } catch (e) {
    final li = LIElement()..text = 'Request failed.';
    wordList.children.add(li);
  }
}

/*
void requestComplete(HttpRequest httpRequest) {
  if (httpRequest.status == 200) {
    final response = httpRequest.responseText;
    if (response != null) {
      readJSON(response);
    }
  } else {
    final li = LIElement()..text = 'Request failed.';
    wordList.children.add(li);
  }
}
*/

void readJSON(String jsonStr) {
  wordList.children = [];
  for (final word in json.decode(jsonStr)) {
    final li = LIElement()..text = word;
    wordList.children.add(li);
  }
}
