void main() {
  const lista = [
    "Adriano",
    "Marco",
    "Gianluigi",
    "Alberto",
    "Franco",
    "Ada",
    "Maria"
  ];

  /*
  for (var i = 0; i < lista.length; i++) {
    var nome = lista[i];
    print(numero);
  }
  */

  for (var nome in lista) {
    print(nome);
  }
}
