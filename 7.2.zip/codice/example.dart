void main() {
  Set<String> set = {'adriano', 'mario', 'giovanni'};

  print(set.join(';'));
  set.add('marco');
  print(set.join(';'));
}
