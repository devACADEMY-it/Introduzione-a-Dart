class Greetable {
  String greet() {
    return "";
  }
}

class Person implements Greetable {
  String name = '';
  String surname = '';
  DateTime dateOfBirth;

  int get age => DateTime.now().difference(dateOfBirth).inDays ~/ 365;

  Person(this.name, this.surname, this.dateOfBirth);

  void describe() {
    print("$name $surname, nato il $dateOfBirth ($age anni)");
  }

  String greet() {
    return "Ciao! Sono ${this.name} ${this.surname}";
  }
}

class Student implements Greetable {
  String badgeNumber = '';
  String department = '';

  Student(this.badgeNumber, this.department);

  void info() {
    print("Matricola n. $badgeNumber - Facoltà: $department");
  }

  String greet() {
    return "Ciao! Sono la matricola n. ${this.badgeNumber} di ${this.department}";
  }
}

String greet(Greetable p) => p.greet();

void main() {
  Person person1 = new Person("Adriano", "Grimaldi", DateTime(1991, 10, 9));
  Student student1 = new Student("0132518525", "Informatica");

  print(greet(person1));
  print(greet(student1));
}
