int sum(int a, int b) {
  return a + b;
}

void main() {
  List<int> numeri = [1, 2, 3, 4, 5];
  var nomi = <String>[
    'adriano',
    'matteo',
    'loris',
    'adriano',
    'giovanni',
    'matteo'
  ];
  var insiemeNomi = <String>{'adriano', 'matteo', 'loris'};
  Map<int, String> persona = {1: 'Adriano', 2: 'Grimaldi'};

  Map<int, Map<String, String>> tavolaPeriodica = {
    8: {'symbol': 'O', 'name': 'Ossigeno'},
    16: {'symbol': 'S', 'name': 'Zolfo'},
    34: {'symbol': 'Se', 'name': 'Selenio'},
    52: {'symbol': 'Te', 'name': 'Tellurio'}
  };
}
