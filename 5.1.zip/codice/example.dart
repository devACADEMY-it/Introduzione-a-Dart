// nome: Voyager 1
// lancio: 5 settembre 1977
// potenza: 420 W
// peso: 825.5 Kg

class SondaSpaziale {
  String nome = '';
  DateTime? dataLancio;
  double potenza = 0;
  double peso = 0;

  SondaSpaziale(nome, dataLancio, potenza, peso) {
    this.nome = nome;
    this.dataLancio = dataLancio;
    this.potenza = potenza;
    this.peso = peso;
  }
}

void main() {
  /*
  Map sonda = {
    nome: "Voyager 1",
    dataLancio: DateTime(1977, 9, 5),
    potenza: 420,
    peso: 825.5
  };
  */

  var voyager1 =
      new SondaSpaziale("Voyager 1", DateTime(1977, 9, 5), 420, 825.5);
  var voyager2 =
      new SondaSpaziale("Voyager 2", DateTime(1977, 8, 20), 420, 825.5);
}
