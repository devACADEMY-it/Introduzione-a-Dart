void main() {
  var lista = [10, 21, 6, 8, 41];

  // print(lista[0]);
  // print(lista[4]);

  for (var i = 0; i < lista.length; i++) {
    print(lista[i]);
  }
}
