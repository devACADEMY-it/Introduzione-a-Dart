String saluta(String from, String msg, [String? device]) {
  var result = '$from saluta dicendo $msg';
  if (device != null) {
    result = '$result con $device';
  }
  return result;
}

void main() {
  var result = saluta("Adriano", "hello", "segnali di fumo");
  print(result);
}
