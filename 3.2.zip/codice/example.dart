void main() {
  // stampare i numeri da 1 a 10
  for (var i = 1; i <= 10; i++) {
    print(i);
  }

  print("Fuori dal ciclo for");
}
